﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 WindowsThemeColorFixer.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_WINDOWSTHEMECOLORFIXER_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       130
#define IDC_REDUCE_COLOR_CHECK          1000
#define IDC_BUTTON1                     1001
#define IDC_BUTTON2                     1002
#define IDC_ADJUST_COLOR_BUTTON         1002
#define IDC_AUTO_RUN_CHECK              1003
#define IDC_HIDE_MAIN_WINDOW_CHECK      1004
#define IDC_STATIC_VERSION              1005
#define IDC_STATIC_COPYRIGHT            1006
#define ID_SETTINGS                     32771
#define ID_1_32772                      32772
#define ID_MENU_EXIT                    32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
