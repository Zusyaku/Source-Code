# Test lexers
# build lexilla.so and TestLexers then run TestLexers
cd ../src
make
cd ../test
make
make test
