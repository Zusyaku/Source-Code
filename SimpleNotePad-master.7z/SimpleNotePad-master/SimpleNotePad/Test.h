﻿#pragma once
class CTest
{
public:
    static void Test();

private:
    static void TestXml();
};

