﻿#include "stdafx.h"
#include "Test.h"
#include "TinyXml2Helper.h"
#include "SyntaxHighlight.h"

void CTest::Test()
{
    TestXml();
}

void CTest::TestXml()
{
    //tinyxml2::XMLDocument doc;

    //CTinyXml2Helper::LoadXmlFile(doc, L"./lang.xml");

    //CTinyXml2Helper::IterateChildNode(doc.FirstChildElement(), [](tinyxml2::XMLElement* child)
    //{
    //    int a = 0;
    //});

    //CSyntaxHighlight syntax;
    //syntax.LoadFromFile("./lang.xml");
    int a = 0;
}
