# SimpleNotePad
这是一个可以代替Windows记事本的软件，除了包含记事本原有的功能外，还支持各种编程语言的语法高亮，还有编码格式转换、十六进制查看编辑、文件二进制比较、编码批量转换的功能。

![主界面](images/1.png)

## 下载链接：

请[点击此处](https://github.com/zhongyang219/SimpleNotePad/releases/latest)下载SimpleNotePad的最新版本。

