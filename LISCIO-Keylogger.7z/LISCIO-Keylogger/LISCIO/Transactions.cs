﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISCIO
{
    static public class Transactions
    {
        public static bool visualTracking=false;
        public static string startUp;
        public static string errorMessage;
    }
}
